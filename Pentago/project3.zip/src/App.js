


function App() {
  return (
    <h1>Hello CS 470 Students. It is Wednesday.</h1>
  );
}

export default App;
