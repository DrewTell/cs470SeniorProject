import { AccessTimeOutlined } from "@mui/icons-material";
import {NUM_COLUMNS, NUM_ROWS} from "./constants";
import doWeHaveAWinner from "./doWeHaveAWinner";

const  advanceColor = (color) => color === 'blue' ? 'red' : 'blue';

function createInitialState() {
    // The board is a 2D array of Objects. Each Object holds the state of the "cell" that it represents.
    // Each of the elements of firstAvailableIndex contains an index for each column of the 2D array.
    // The value at the index specifies which row in that column a disk can be deposited.

    let board = Array(NUM_ROWS).fill(Array(6).fill({color: "white", isOccupied: false}));
    board.map((row, rowIdx) => row.map( (col, colIdx) => {
        return {...board[rowIdx][colIdx], row: rowIdx, column: colIdx }
    }));

    return {
        board,
        hasRotated: false,
        quadrantToRotate: -1,
        haveAWinner: false,
        nextColor: 'blue',
        timeToRotate: false,

    };
}

function integrateClick(state, colIdx, rowGroup, timeToRotate) {

    let board = state.board;
    let affectedRow = board[rowGroup].slice();
    affectedRow[colIdx] = {
        ...affectedRow[colIdx],
        color: state.nextColor,
        isOccupied: true
    };
    let newBoard = board.slice();
    newBoard[rowGroup] = affectedRow;
    const activeColor = state.nextColor;

    let newState = {
        ...state,
        board: newBoard,
        timeToRotate: true,
    };

    if( doWeHaveAWinner(rowGroup, colIdx, activeColor, board) ) {
        newState = {
            ...newState,
            haveAWinner: true,
            winnerColor: activeColor
        };
    }

    return newState;
}




function integrateRotation(state, direction) {

    function rotateCounterClockwise(arrayToRotate){
        var arraySize = arrayToRotate.length;
        for (var i = 0; i < arraySize / 2; i++) {
            for (var j = i; j < arraySize - i - 1; j++) {
                var tmp = arrayToRotate[i][j];
                arrayToRotate[i][j] = arrayToRotate[j][arraySize-i-1];
                arrayToRotate[j][arraySize-i-1] = arrayToRotate[arraySize-i-1][arraySize-j-1];
                arrayToRotate[arraySize-i-1][arraySize-j-1] = arrayToRotate[arraySize-j-1][i];
                arrayToRotate[arraySize-j-1][i] = tmp;
            }
        }
        return arrayToRotate;
    }

    function rotateClockwise(arrayToRotate) {
        var arraySize = arrayToRotate.length;
        for (var i=0; i<arraySize/2; i++) {
            for (var j = i; j < arraySize - i - 1; j++) {
                var tmp = arrayToRotate[i][j];
                arrayToRotate[i][j] = arrayToRotate[arraySize-j-1][i];
                arrayToRotate[arraySize-j-1][i] = arrayToRotate[arraySize-i-1][arraySize-j-1];
                arrayToRotate[arraySize-i-1][arraySize-j-1] =arrayToRotate[j][arraySize-i-1];
                arrayToRotate[j][arraySize-i-1] = tmp;
            }
        }
        return arrayToRotate;
    }
    
    var rowIndexColumnIndex = [];
    var rowManual = [];
    switch(state.quadrantToRotate){
        case "Top Left":
            rowIndexColumnIndex = [0, 3, 0, 3];
            rowManual = [0, 1, 2];
            break;
        case "Top Right":
            rowIndexColumnIndex = [0, 3, 3, 6];
            rowManual = [0, 1, 2];
            break;
        case "Bottom Left":
            rowIndexColumnIndex = [3, 6, 0, 3];
            rowManual = [3, 4, 5];
            break;
        case "Bottom Right":
            rowIndexColumnIndex = [3, 6, 3, 6];
            rowManual = [3, 4, 5];
            break;
        default:
            return Error;
    }

    let board = state.board;
    var quadrantValues = [];
    console.log("Board at index 0 and down");
    console.log(board[0]);
    // console.log(board[1]);
    // console.log(board[2]);
    var row1 = board[rowManual[0]].slice(rowIndexColumnIndex[2], rowIndexColumnIndex[3]);
    var row2 = board[rowManual[1]].slice(rowIndexColumnIndex[2], rowIndexColumnIndex[3]);
    var row3 = board[rowManual[2]].slice(rowIndexColumnIndex[2], rowIndexColumnIndex[3]);
    quadrantValues.push(row1, row2, row3);
    console.log("quadrantValues", quadrantValues);
    console.log("-----meh--------");



    // for (var i = rowIndexColumnIndex[0]; i < rowIndexColumnIndex[1]; i++){
    //     console.log(board[i].slice(rowIndexColumnIndex[2],rowIndexColumnIndex[3]));
    //     quadrantValues.push(board[i].slice(rowIndexColumnIndex[2],rowIndexColumnIndex[3]));
    //     console.log("This is board[i] i=", i, "rowIndexColumnIndex:", rowIndexColumnIndex[2], rowIndexColumnIndex[3], " ", board[i].slice(rowIndexColumnIndex[2],rowIndexColumnIndex[3]));
    //     console.log("This is quadrant values: ", i, "in loop: ", quadrantValues);

        
    // }
    // console.log("This is quadrant values right after looping:  ", quadrantValues);

    if (direction === "Left"){
        quadrantValues = rotateCounterClockwise(quadrantValues);
    }

    if (direction === "Right"){
        // transposeGrid rotates by 90 degrees
        quadrantValues = rotateClockwise(quadrantValues);
    }

    let affectedRow1 = board[rowManual[0]].slice();
    let affectedRow2 = board[rowManual[1]].slice();
    let affectedRow3 = board[rowManual[1]].slice();
    let tempValue = 0;
    if (direction === "Left"){
        for (var y = rowIndexColumnIndex[2]; y < rowIndexColumnIndex[3]; y++){
            console.log("affected row", affectedRow1);
            affectedRow1[y] = {
                color: quadrantValues[0][y].color,
                isOccupied: quadrantValues[0][y].isOccupied
            };
            affectedRow2[y] = {
                color: quadrantValues[1][y].color,
                isOccupied: quadrantValues[0][y].isOccupied
            };
    
            affectedRow3[y] = {
                color: quadrantValues[2][y].color,
                isOccupied: quadrantValues[0][y].isOccupied
            };
    
        }
    }
    if (direction === "Right") {
        for (var y = rowIndexColumnIndex[2]; y < rowIndexColumnIndex[3]; y++){
            console.log("affected row", affectedRow1);
            affectedRow1[y] = {
                color: quadrantValues[0][tempValue].color,
                isOccupied: quadrantValues[0][tempValue].isOccupied
            };
            affectedRow2[y] = {
                color: quadrantValues[1][tempValue].color,
                isOccupied: quadrantValues[0][tempValue].isOccupied
            };
    
            affectedRow3[y] = {
                color: quadrantValues[2][tempValue].color,
                isOccupied: quadrantValues[0][tempValue].isOccupied
            };
            tempValue += 1;
        }
    }


    console.log("This is quadrantValues after rotation", quadrantValues);
    
    let newBoard = board.slice();
    newBoard[rowManual[0]] = affectedRow1;
    newBoard[rowManual[1]] = affectedRow2;
    newBoard[rowManual[2]] = affectedRow3;

    // let rotatedGridX = 0;
    // let rotatedGridY = 0;
    // for (var x = rowIndexColumnIndex[0]; x < rowIndexColumnIndex[1]; x++){
    //     rotatedGridY = 0;
    //     for (var y = rowIndexColumnIndex[2]; y < rowIndexColumnIndex[3]; y++){
    //         // console.log("This is newBoard current", newBoard[x][y]);
    //         // console.log("This is quadrantValues:", quadrantValues[rotatedGridX][rotatedGridY]);
    //         newBoard[x][y] = quadrantValues[rotatedGridX][rotatedGridY];
            
    //         // console.log("Filling the values: ", rotatedGridX, rotatedGridY);
    //         // console.log("Being filled into the new board at: ", x, y);
    //         rotatedGridY += 1;
    //     }
    //     rotatedGridX += 1;
    // }
    const activeColor = state.nextColor;
    // console.log("active color", activeColor);
    // console.log(advanceColor(activeColor));

    let newState = {
        ...state,
        board: newBoard,
        timeToRotate: false,
        rotationChoice: -1,
        nextColor: advanceColor(activeColor),
    };

    console.log("this is new state", newState);

    console.log(board, newBoard);

    return newState;
}


function integrateRotationChoice(state, quadrantChoice) {
    let newState = {
        ...state,
        quadrantToRotate: quadrantChoice,
    };
    return newState;
}

function reducers(state, action) {
    // console.log("This is state in reducer: ", state);
    // console.log("This is action in reducer: ", action);

    if( state === undefined )
        return state;

    // console.log(`in reducers. action.type is: ${action.type}, board contains: ${JSON.stringify(state)}`);

    if( action.type === 'RESET' ) {
        return createInitialState();
    } else if( action.type === 'CELL_CLICKED') {
        if( state.haveAWinner )
            return state;

        if(state.board[action.rowGroup][action.colIdx].color !== 'white')  // column is full
            return state;
        if(state.timeToRotate === true){
            return state;
        }
        return integrateClick(state, action.colIdx, action.rowGroup);
    }
    else if (action.type === 'BUTTON_CLICKED' && state.timeToRotate) {
        return integrateRotationChoice(state, action.quadrant);
        }
    else if(action.type === 'ROTATION_CLICKED' && (state.quadrantToRotate !== -1) && state.timeToRotate){
        return integrateRotation(state, action.direction);
    }

    return state;

}

export {
    reducers,
    createInitialState
};